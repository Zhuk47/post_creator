/**
 * Created by Zhukoff on 14.02.2018.
 */

jQuery(function ($) {

    $('.post-content div').show();

});
